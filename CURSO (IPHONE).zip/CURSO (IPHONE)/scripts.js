
function TrocaCor(cor){
    let circulo = document.querySelector(".circulo")
    circulo.style.background = cor
}

function trocaImagem(imagem){
    let imgIphone = document.querySelector(".iphone")
    imgIphone.src = imagem

}